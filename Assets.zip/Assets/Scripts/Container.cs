using UnityEngine;
using UnityEngine.UI;

public class Container : MonoBehaviour
{
    public GameObject _container = null;
    [SerializeField] private float amountFilled = 0;
    [SerializeField] private float secondsToFillGlass = 1;
    [SerializeField] private float timeReducedByTapping = 0.25f;
    [SerializeField][Range(1, 4)] int drinknumber = 1;
    //[SerializeField] private Button drinkButton;



    [SerializeField] Transform drink;
    [SerializeField] DrinkDelivery drinkDelivery;

    private void Update()
    {
        if (_container != null)
            return;

        amountFilled += Time.deltaTime / secondsToFillGlass;

        if (amountFilled >= 1.0f && _container == null)
        {
            //drinkButton.interactable = true;
            //_container.SetActive(true);
            drinkDelivery.CreateDrink(drinknumber, gameObject.transform);
            amountFilled = 0f;
        }
    }
}