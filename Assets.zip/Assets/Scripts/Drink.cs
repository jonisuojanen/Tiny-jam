using UnityEngine;

public class Drink : MonoBehaviour
{

        [SerializeField] private float amountFilled = 0;
        [SerializeField] private float secondsToFillGlass = 1;
        [SerializeField] private float timeReducedByTapping = 0.25f;

        [SerializeField] Sprite glass1;
        [SerializeField] Sprite glass2;
        [SerializeField] Sprite glass3;
        [SerializeField] Sprite glass4;
        [SerializeField] Sprite glass5;

        Animation fillAnimation;
        SpriteRenderer sprite;

        private void Start()
        {
            fillAnimation = GetComponent<Animation>();
            sprite = gameObject.GetComponent<SpriteRenderer>();
        }

        void Update()
        {
            amountFilled += Time.deltaTime / secondsToFillGlass;

            switch (amountFilled)
            {
                case < 0.5f:
                    sprite.sprite = glass1;
                    break;
                case < 1.0f:
                    sprite.sprite = glass2;
                    break;
                case < 1.5f:
                    sprite.sprite = glass3;
                    break;
                case < 2.0f:
                    sprite.sprite = glass4;
                    break;
                case >= 2.5f:
                    sprite.sprite = glass5;
                    break;
            }

            if (amountFilled >= 1)
            {
                //Make interactable
            }
        }

        public void FillFaster()
        {
            amountFilled += timeReducedByTapping / secondsToFillGlass;
        }
}