
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class DrinkDelivery : MonoBehaviour
{
    //public List<Transform> drinkList = new List<Transform>();

    public List<Transform> tapList = new List<Transform>();

    [SerializeField] Transform bartender;



    [SerializeField] Transform customer1;
    [SerializeField] Transform customer2;
    [SerializeField] Transform customer3;
    [SerializeField] Transform customer4;

    private static int money;
    public Transform drinkPrefab;
    public Transform _drinkPrefab1;
    public Transform _drinkPrefab2;
    public Transform _drinkPrefab3;
    public Transform _drinkPrefab4;

    Container container1;
    Container container2;
    Container container3;
    Container container4;

    //private Container container;

    private GameBehaviour gameBehaviour;

    private void Awake()
    {
        gameBehaviour = gameObject.GetComponent<GameBehaviour>();
    }

    //select customer
    #region Customers

    public void SelectCustomer1()
    {

        DeliverToCustomer(1);
        //Debug.Log("It Works");
    }
    public void SelectCustomer2()
    {

        DeliverToCustomer(2);
    }
    public void SelectCustomer3()
    {

        DeliverToCustomer(3);
    }
    public void SelectCustomer4()
    {

        DeliverToCustomer(4);

    }



    #endregion

    public void CreateDrink(int drinkNumber, Transform tap)
    {
        //drinkPrefab = drinkList[drinkNumber];

        //Find spesified container (tapPoint) use
        Container container = tap.GetComponent<Container>();

        if (container._container != null) { return; }

        if (drinkNumber == 1)
        {
            _drinkPrefab1 = Instantiate(drinkPrefab, tap.position, Quaternion.identity);
            container1 = container;
        }
        if (drinkNumber == 2)
        {
            _drinkPrefab2 = Instantiate(drinkPrefab, tap.position, Quaternion.identity);
            container2 = container;
        }
        if (drinkNumber == 3)
        {
            _drinkPrefab3 = Instantiate(drinkPrefab, tap.position, Quaternion.identity);
            container3 = container;
        }
        if (drinkNumber == 4)
        {
            _drinkPrefab4 = Instantiate(drinkPrefab, tap.position, Quaternion.identity);
            container4 = container;
        }


        //Fill up container
        container._container = drinkPrefab.gameObject;
    }


    void DeliverToCustomer(int customer)
    {
        //add money based on drinks modifier

        if (drinkPrefab == null) { return; }

        gameBehaviour.AddMoney();

        ////Empty Container
        //Destroy(_drinkPrefab.gameObject);

        if (customer == 1)
        {
            Destroy(_drinkPrefab1.gameObject);
            container1._container = null;
        }
        else if (customer == 2)
        {
            Destroy(_drinkPrefab2.gameObject);
            container2._container = null;
        }
        else if (customer == 3)
        {
            Destroy(_drinkPrefab3.gameObject);
            container3._container = null;
        }
        else if (customer == 4)
        {
            Destroy(_drinkPrefab4.gameObject);
            container4._container = null;
        }
    }

    //deliver drink to customer
}
