using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameBehaviour : MonoBehaviour
{
    [SerializeField] private float currentTime = 0;

    private static float pouringSpeed;
    private static int money;

    [SerializeField] TextMeshProUGUI timerText;
    [SerializeField] TextMeshProUGUI coinText;

    [SerializeField] Transform drink;
    [SerializeField] int coinsPerDrink = 2;

    [SerializeField] AudioManager audioManager;
    [SerializeField] private Button hireButton;
    [SerializeField] private Transform customer;


    private float timeSinceActivation = 0;

    private GameState currentState = GameState.beginning;
    private bool canHire = true;

    enum GameState
    {
        beginning,
        SpeedUp,
        end
    }


    private void Awake()
    {
        audioManager = audioManager.GetComponent<AudioManager>();
    }

    // Start is called before the first frame update
    void Start() {}

    // Update is called once per frame
    void Update()
    {
        currentTime += Time.deltaTime;

        int _currentTimeInt = Mathf.RoundToInt(currentTime);
        timerText.text = _currentTimeInt.ToString();

        if (currentTime >= 20)
            currentState = GameState.SpeedUp;
        if (currentTime >= 30)
            currentState = GameState.end;
    }

    private void DrinkFinished()
    {
        //Move Drink to customer
        drink.Translate(customer.position);

        //Play drinkFinished sound
        audioManager.Play("DrinkFinished");
    }

    public void AddMoney()
    {
        money += coinsPerDrink;

        //Amount to UI
        coinText.text = money.ToString();

        //Play Sound
        audioManager.Play("Coin");


        if (money >= 5 && canHire)
        {
            hireButton.interactable = true;

            if (timeSinceActivation >= 5)
            {
                HireNewBartender();
            }
        }
    }

    private void NewDrink()
    {
        coinsPerDrink *= 2;
        //Change Sprite
    }

    public void HireNewBartender()
    {
        canHire = false;
        hireButton.interactable = false;
        money -= 5;
        pouringSpeed += 0.25f;
    }
}